file = open('input4.txt').readlines()
out = open('output4.txt','w')
Maximum = float("infinity")
def Min_way(node,Graph,visited,counter):
    if(node==counter-1): return 0
    visited[node] = 1
    way = Maximum
   
    for i in range(counter):
        if (Graph[node][i]!=Maximum and not visited[i]):
            money = Min_way(i,Graph,visited,counter)
            if(money<Maximum):
                way = min(way,Graph[node][i]+money)
    visited[node] = 0
    return way

Testing= int(file[0])
index = 1
for j in range(Testing):
    start = file[index].strip().split()
    vertices = int(start[0])
    edges = int(start[1])

    Graph = [[Maximum for j in range(vertices)] for i in range(vertices)]
    visit = [0 for i in range(vertices)]
    index = index+1
    for k in range(edges):
        connect = file[index].strip().split()

        ver1 = int(connect[0])
        ver2 = int(connect[1])
        Graph[ver1-1][ver2-1] = 1
        Graph[ver2-1][ver1-1] = 1
        index =index + 1
    visit[0] = 1
    out.write(str(Min_way(0,Graph,visit,vertices))+"\n")