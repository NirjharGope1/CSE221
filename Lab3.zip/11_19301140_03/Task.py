class Graph:
    def __init__(self):
        self.output = open("output.txt", "w")
    #Task01:Make Graph
    def add_edge(self, input):
        file = open(input)
        self.rows = file.readline()
        self.connect = int(file.readline())
        self.dictionary={}
        for i in range(self.connect):
            lines = file.readline()
            lines = " ".join(lines.split())
            x = int(lines[0:2])
            y = int(lines[2:])
            if x in self.dictionary:
                self.dictionary[x].append(y)
            else:
                self.dictionary[x] = []
                self.dictionary[x].append(y)           
    def print_edge(self):
        self.output.write("Graph Representation:-")
        self.output.write("\n")
        for key, values in self.dictionary.items():
            a = key,"----->",values
            self.output.write(str(key))
            self.output.write(" -----> ")
            self.output.write(str(values))
            self.output.write("\n")
        self.output.write("\n")
    #Task02:BFS              
    def bfs(self, visited, starting, ending):
        queue = []
        visited *= (int(self.rows)+1) 
        queue.append(starting)
        visited[starting] = True
        new_array = []
        while queue:
            delete = queue.pop(0)
            new_array.append(delete)
            if ending in new_array:
                break 
            if delete not in self.dictionary:
                continue
            else: 
                for i in self.dictionary[delete]:
                    if visited[i] == False:
                        queue.append(i)
                        visited[i] = True 
        self.output.write("Breadth-First Search(BFS):- ")
        string_list = ' '.join([str(i) for i in new_array])
        self.output.write(string_list)
        self.output.write("\n")
    #Task03:DFS
    def dfs(self, visited, startingnode, endingnode):
        while startingnode not in visited:
            visited.append(startingnode)
                  
            for vertices in self.dictionary[startingnode]:
                if vertices not in self.dictionary:
                    visited.append(vertices)
                else: 
                    self.dfs(visited, vertices, endingnode)

        visited= visited[:visited.index(endingnode)+1]
        return visited

    def print_dfs(self,x):
        self.output.write("Depth-First Search:- ")
        self.output.write(x)

x=Graph()
x.add_edge("input ext.txt")
x.print_edge()
x.bfs([0], 1, 12)
dfs=x.dfs([], 1, 12)
dfs_list_to_str= " ".join([str(i) for i in dfs])
x.print_dfs(dfs_list_to_str)