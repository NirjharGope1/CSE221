from queue import PriorityQueue
class Graph:
    def __init__(self, Nodenum):
        self.v = Nodenum 
        self.Edges = [[-1 for i in range(Nodenum+1)] for j in range(Nodenum+1)]
        self.visit = []
    def add_edges(self, X, Z, Weighted):
        self.Edges[X][Z] = Weighted 
        self.Edges[Z][X] = Weighted
    def print_edges(self):
        print(self.Edges)

    def dijkstra(self, Starting):  
        D = {v:float("inf") for v in range(Starting, self.v)}
        prev = [None for v in range(self.v)]
        D[Starting] = 0
        prev[0] = Starting 
        Q = PriorityQueue()
        Q.put((0, Starting))    
        while not Q.empty():
            (dist, RunningNode) = Q.get()   
            
            self.visit.append(RunningNode)
            for Relations in range(self.v):
                if self.Edges[RunningNode][Relations] != -1:
                    Distance = self.Edges[RunningNode][Relations]
                    if Relations not in self.visit:
                        Old = D[Relations]
                        New = D[RunningNode]+Distance
                        if New < Old:
                            Q.put((New, Relations))
                            D[Relations] = New
                            if RunningNode in prev:
                                continue
                            else: 
                                prev[Relations] = RunningNode
                            
        self.new_prev = []
        for i in prev:
            if i == None: 
                continue 
            else:
                self.new_prev.append(i)
        return self.new_prev 
       
file = open("input2.txt")
output = open("output2.txt", "w")
test = file.readline()
v = file.readline().split()
toInt = list(map(int, v))
if toInt[1] == 0:
    output.write(str(toInt[0]))   
output.write("\n")
v = file.readline().split()
toInt = list(map(int, v))
if toInt[1] == 1:   
    v = file.readline().split()
    toInt = list(map(int, v))
    output.write(str(toInt[0]))
    output.write(" ")
    output.write(str(toInt[1]))
output.write("\n")
v = file.readline().split()
toInt = list(map(int, v))
nodes = toInt[1] 
g = Graph(nodes)
for i in range(nodes):
    v = file.readline().split()
    toInt = list(map(int, v))
    g.add_edges(toInt[0], toInt[1], toInt[2])
D = g.dijkstra(1)

def shortest_path(D, Target):
    for i in D:
        if i <= Target:
            output.write(str(i))
            output.write(" ")
    output.write(str(Target))
shortest_path(D, 5)

        

