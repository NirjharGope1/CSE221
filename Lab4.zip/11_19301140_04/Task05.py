from queue import PriorityQueue
file=open('input5.txt')
file=file.read()
function1=file.split('\n')
for X in range(len(function1)):
    if X==0:
        function1[X]=int(function1[X])
    elif function1[X] !='':
        a=function1[X].split(' ')
        function1[X]=[]
        for x1 in a:
            x1=int(x1)
            function1[X]=function1[X]+[x1]
    else:
        function1.remove(function1[X])
G=[]
x1=0
Source=[]
for X in range(0,function1[0]):
    x1=x1+1
    if function1[x1][1]==0:
        g1={function1[x1][0]:function1[x1][1]}
        x1=x1+1
        Source.append(function1[x1][0])
    else:
        g1={}
        nodes=function1[x1][0]
        for x2 in range(0,function1[x1][1]):
            x1=x1+1
            p=function1[x1][0]
            y=function1[x1][1]
            z=function1[x1][2]
            if p in g1:
                temp=[y,z]
                g1[p].append(temp)
            else:
                g1[p]=[]
                temp=[y,z]
                g1[p].append(temp)
        for y in range(1,nodes+1):
            if y not in g1.keys():
                g1[y]=[]
        x1=x1+1
        Source.append(function1[x1][0])
    g1=dict(sorted(g1.items()))
    G.append(g1)
def Dijkstra(Graph,source):
    Dic=[10000]* len(Graph)
    Dic[source-1]=0
    q=PriorityQueue()
    visit=[False]*len(Graph)
    prev=[0]*len(Graph)
    for key in Graph:
        if key!=source:
            Dic[key-1]=-1
            prev[key-1]=0
        visit[key-1]=False
    q.put((-1*(Dic[source-1]),source))
    while not q.empty():
        u=q.get()
        u=u[1]
        if visit[u-1]==True:
            continue
        visit[u-1]=True
        if type(Graph[u])==list:
            for x1 in Graph[u]:
                if Dic[u-1]==0:
                    alt=x1[1]
                else:
                    alt=min(Dic[u-1],x1[1])
                if alt>Dic[x1[0]-1]:
                    Dic[x1[0]-1]=alt
                    prev[x1[0]-1]=u
                    q.put((-1*(x1[1]),x1[0]))
        else:
            return Dic,prev
    return Dic,prev
fileout=open('output5.txt','w')
for X,y in zip(G,Source):
    q=Dijkstra(X,y)
    for x1 in q[0]:
        fileout.write(str(x1))
        fileout.write(' ')
    fileout.write('\n')