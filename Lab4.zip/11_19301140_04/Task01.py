from queue import PriorityQueue
class Graph:
    def __init__(self, NodesNum):
        self.v = NodesNum 
        self.Edges = [[-1 for i in range(NodesNum+1)] for j in range(NodesNum+1)]
        self.visit = []
    def add_edges(self, Y, Z, Weighted):
        self.Edges[Y][Z] = Weighted 
        self.Edges[Z][Y] = Weighted
    def print_edges(self):
        print(self.Edges)
    
    def dijkstra(self, Starting):  
        Df = {v:float("inf") for v in range(Starting, self.v)}
        Df[Starting] = 0
        Q = PriorityQueue()
        Q.put((0, Starting))    
        while not Q.empty():
            (dist, RunningNode) = Q.get() 
            self.visit.append(RunningNode)
            for Relative in range(self.v):
                if self.Edges[RunningNode][Relative] != -1:
                    Distance = self.Edges[RunningNode][Relative]
                    if Relative not in self.visit:
                        Old = Df[Relative]
                        New = Df[RunningNode]+Distance
                        if New < Old:
                            Q.put((New, Relative))
                            Df[Relative] = New
                            
        return Df
file = open("input1.txt")
output = open("output1.txt", "w")
test = file.readline()
a = file.readline().split()
toInt = list(map(int, a))
if toInt[1] == 0:
    output.write(str(0))
output.write("\n")
a = file.readline().split()
toInt = list(map(int, a))
if toInt[1] == 1:
    a = file.readline().split()
    toInt = list(map(int, a))
    output.write(str(toInt[2]))
output.write("\n")
a = file.readline().split()
toInt = list(map(int, a))
nodes = toInt[1] 
g = Graph(nodes)
for i in range(nodes):
    a = file.readline().split()
    toInt = list(map(int, a))
    g.add_edges(toInt[0], toInt[1], toInt[2])
Dij = g.dijkstra(1)
output.write(str(Dij[5]))




