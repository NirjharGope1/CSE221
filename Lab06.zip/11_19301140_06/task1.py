Function=open("input1.txt",'r')
Initial=[]
for i in Function:
    Counter=0
    D=i.rstrip("\n")
    while(True):
        if(len(D)>1):
            s=[int(i) for i in D]
            Seque=max(s)
            Backup=int(D)-Seque
            D=str(Backup)
            Counter+=1
        elif(len(D)==1):
            Counter+=1
            break
    Initial.append(Counter)
Function.close()
Function=open("output1.txt",'w')
for i in Initial:
    Function.write(str(i)+"\n")
Function.close()