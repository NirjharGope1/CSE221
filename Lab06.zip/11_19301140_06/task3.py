def lcs(A, B, C):
    
    m = len(A)
    n = len(B)
    o = len(C)
    LCS = [[[0 for i in range(o+1)] for j in range(n+1)] for k in range(m+1)]

    for i in range(m+1):
        for j in range(n+1):
            for k in range(o+1):
                if i==0 or j==0 or k==0:
                    LCS[i][j][k]=0
                elif A[i-1] == B[j-1] and A[i-1] == C[k-1]:
                    LCS[i][j][k] = 1 + LCS[i-1][j-1][k-1]
                else: 
                    LCS[i][j][k] = max(max(LCS[i-1][j][k], LCS[i][j-1][k]), LCS[i][j][k-1])

    a = LCS[m][n][o]
    return a 
input = open("input3.txt")
A = input.readline().split(" ")
A = "".join(A)
B = input.readline().split(" ")
B = "".join(B)
C = input.readline().split(" ")
C = "".join(C)
a = lcs(A, B, C)
output_file = open("output3.txt","w")
output_file.write(str(a))