import sys
def LCS(X, Y):
    m = len(X) + 1
    n = len(Y) + 1
    c = []
    t = []
    Pubg = {"Y": "Yasnaya", "R": "Rozhok",
        "S": "School", "P": "Pochinki",
        "F": "Farm", "M": "Mylta",
        "H": "Shelter", "I": "Prison"}
    for i in range(m):
        array = list()
        for j in range(n):
            array.append(0)
        c.append(array)
    for i in range(m):
        array = list()
        for j in range(n):
            array.append("N")
        t.append(array)
    for i in range(1, m):
        for j in range(1, n):
            if X[i - 1] is Y[j - 1]:
                c[i][j] = c[i - 1][j - 1] + 1
                t[i][j] = "d"
            elif c[i - 1][j] >= c[i][j - 1]:
                c[i][j] = c[i - 1][j]
                t[i][j] = "u"
            else:
                c[i][j] = c[i][j - 1]
                t[i][j] = "l"

    b = m - 1
    c = n - 1

    new_List = list()
    while "N" not in t[b][c]:
        if "d" in t[b][c]:
            new_List.append(X[c - 1])
            b = b - 1
            c = c - 1

        elif "l" in t[b][c]:
            c = c - 1

        else:
            b = b - 1

    new_List.reverse()

    for i in new_List:
        print("{}".format(Pubg[i]), end=" ")
    print()

    return new_List
sys.stdin = open("input2.txt", "r")
sys.stdout = open("output2.txt", "w")
Tzone = int(input())
X = input()
Y = input()

lczs = LCS(X, Y)

Correct = (len(lczs) * 100) / Tzone
print("Correctness of prediction: {}%".format(int(Correct)))
