fdata=open('input3.txt')
fdata=fdata.read()
p=open('output3.txt','w')
data=fdata.split("\n")

a=[0]*5
p=[0]*5

c=len(data)//2

for k in range(0,c):
    a[k]=data[k]
    
d=c
for m in range(0,len(p)):
    p[m]=data[d]
    d=d+1


for i in range(0,len(p)):
    
    for j in range(i-1,-1,-1):
        
        if(p[j]<p[j+1]):
            temp =p[j]
            temp1=a[j]

            p[j]=p[j+1]
            a[j]=a[j+1]

            p[j+1]=temp
            a[j+1]=temp1

        else:
            break


print(a,file=p)
p.close()
