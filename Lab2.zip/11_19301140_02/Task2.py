fdata=open('input2.txt')
fdata=fdata.read()
p=open('output2.txt','w')
data=fdata.split("\n")

for k in range(0,len(data)):
    data[k]=int(data[k])

max = 0

maximum = data[0]


for i in range(len(data)-1,-1,-1):

    maximum = data[i]

    max = i
    for j in range(0,i):

      if(data[j]>maximum):

        maximum = data[j]

        max = j

    temp = data[max]

    data[max]=data[i]

    data[i]=temp


for m in range(0,3):
    print(data[m],file=p)
p.close()

