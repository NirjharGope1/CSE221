fdata=open('input1.txt')
fdata=fdata.read()
p=open('output1.txt','w')
data=fdata.split("\n")
for k in range(0,len(data)):
    data[k]=int(data[k])

def BubbleSort(data):
    for j in range(0,len(data)-1): #For the best case scenario , in this loop...The time complexity is O(n)
        if data[j]<data[j+1]:
            print(data,file=p)
        else:
            
            for i in range(len(data)-1,-1,-1):
                for j in range(0,i):
                    if data[j]>data[j+1]:
                        temp = data[j] 
                        data[j]=data[j+1]
                        data[j+1]=temp
                    

BubbleSort(data)
print(data,file=p)
p.close()



