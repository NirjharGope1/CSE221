fdata=open('input4.txt')
fdata=fdata.read()
ansu=open('output4.txt','w')
data=fdata.split("\n")

for k in range(0,len(data)):
    data[k]=int(data[k])

def merge(lp,rp):
    list=[]
    i=0
    j=0
    while i<len(lp) and j< len(rp):
        if lp[i]<= rp[j]:
            list.append(lp[i])
            i+=1
        else:
            list.append(rp[j])
            j+=1
    list = list+lp[i:]
    list = list+rp[j:]
    return list

def m(a):
    if (len(a)<=1):
        return a
    mid=int(len(a)//2)
    left=m(a[:mid])
    right=m(a[mid:])
    return merge(left,right)

print(m(data),file=p)
p.close()
    

