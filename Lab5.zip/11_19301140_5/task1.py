def Operation1(s, e):
    Value = s.read().split("\n")
    Myarray = []
    for i in range(1, (int(Value[0]) + 1)):
        Myarray.append(list(map(int, Value[i].split(" "))))
    SortArray = sorted(Myarray, key=lambda l: l[1])
    Detect = []
    Detect.append(SortArray[0])
    ArrIndex = SortArray[0][1]
    del(SortArray[0])
    Counter = 1
    s = open("input1.txt", "r")
    e = open("output1.txt", "w")
    Operation1(s, e)
    for i in range(len(SortArray)):
        x = SortArray[0][0]
        y = Detect[-1][1]
        if x >= y:
            Counter += 1
            ArrIndex += SortArray[0][1]
            Detect.append(SortArray[0])
        del(SortArray[0])
    e.write(str(Counter) + "\n")
    for j in Detect:
        e.write(("{} {}\n").format(str(j[0]), str(j[1])))
    s.close()
    e.close()

