def Squares(a,b):
    squareCount = 0
    N = 1
    while N*N <= b:        
        if N*N >= a:
           squareCount += 1         
        N+=1
    return squareCount                
try:
        S = open("input4.txt","r")
        e = open("output4.txt","w")
        lines = S.readlines()
        squares = []
        for line in lines:
            Value = line.strip().split(" ")
            a = int(Value[0])
            b = int(Value[1])
            if a == 0 and b == 0:
                break
            sum = Squares(a,b)
            squares.append(sum)
        for sum in squares:
            e.write(str(sum)+"\n")
except:
        print("")