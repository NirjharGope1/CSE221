import sys
def Score(key,X,Op1):
    Dicc={}
    Counter=0
    for i in key:
        Dicc[i]=X[i]
    Element= [[]]*Op1
    for i in Dicc:
        for j in Dicc[i]:
            for k in range(len(Element)):
                if len(Element[k])==0:
                    Element[k]=[i]
                    Counter +=1
                    break
                elif Element[k][-1] <=j:
                    Element[k].append(i)
                    Counter +=1
                    break
    print(Counter)
sys.stdin=open('input2.txt','r')
sys.stdout=open('output2.txt','w')
N,M=open("input2.txt",'r').readline().split()
Dicct1={}
list1=[]
for i in range(int(N)+1):
    S_n,F_n=input().split()
    temp=[int(S_n),int(F_n)]
    list1.append(temp)
for i in range(1,len(list1)):
    s_n=list1[i][0]
    f_n=list1[i][1]
    if f_n not in Dicct1:
        Dicct1[f_n]=[s_n]
    else:
        Dicct1[f_n].append(s_n)
keys=sorted(Dicct1.keys())
Score(keys,Dicct1 ,int(M))



