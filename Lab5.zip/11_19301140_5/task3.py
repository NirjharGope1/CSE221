import queue
def Schedule(x):
    Operation=x[2]
    Myarray=[]
    Up=x[1].split()
    for i in range(int(x[0])):
        Myarray.append(int(Up[i]))
    Myarray.sort()
    JAC=queue.PriorityQueue()
    Formation=[]
    Jack=[]
    Jil=[]
    index=0
    for i in Operation:
        if i =='J':
            JAC.put(((-1*index),Myarray[index]))
            Jack.append(Myarray[index])
            Formation.append(Myarray[index])
            index +=1
        else:
            if i =='j':
                P1=JAC.get()[1]
                Jil.append(P1)
                Formation.append(P1)
    Sum=0
    Counter=0
    for i in range(len(Jack)):
        Sum=Sum+Jack[i]
    for i in range(len(Jil)):
        Counter=Counter+Jil[i]
    for i in Formation:
        print(i,end='', file=e)
    print(file=e)
    print("Jack will work for",Sum,'hours', file=e)
    print("Jill will work for",Counter,'hours', file=e)

S=open('input3.txt','r')
e=open('output3.txt','w')
f=S.readlines()
r=Schedule(f)
S.close()
e.close()




